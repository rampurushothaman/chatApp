import { useRef } from "react";
import { useEffect, useState } from "react";
import styles from "./SelectedFilters.module.css";

function SelectedFilters({ filters }) {
  const selectedFilterRef = useRef();
  const [isBadgeVisible, setBadgeVisibile] = useState(false);
  const [isClearVisible, setClearVisible] = useState(false);
  const [displayedFilters, setDisplayedFilters] = useState([]);
  const [hiddenFilters, setHiddenFilters] = useState([]);

  useEffect(() => {
    const arrangeFilters = () => {
      const selectedFilterEl = selectedFilterRef.current;

      const container = document.createElement('div');
      container.style.visibility = 'hidden';
      selectedFilterEl.appendChild(container);

      const containerWidth = container.clientWidth;


      const filtersWidths = [];
      filters.forEach((filter) => {
        const filterEl = document.createElement("span");
        filterEl.classList.add(styles.filter);
        filterEl.textContent = filter;
        container.appendChild(filterEl);
        filtersWidths.push(filterEl.getBoundingClientRect().width + 16);
      });

      const clearbutton = document.createElement("button");
      clearbutton.textContent = "Clear All";
      clearbutton.classList.add(styles.clearAll);
      container.appendChild(clearbutton);

      const clearAllWidth = clearbutton.clientWidth + 16;

      const badge = document.createElement("span");
      badge.classList.add(styles.badge);
      badge.style.display = "inline-block";
      badge.textContent = "+100";
      container.appendChild(badge);

      const badgeWidth = badge.clientWidth + 16;

      const totalFiltersWidth = filtersWidths.reduce(
        (sum, filterWidth) => sum + filterWidth
      );

      if (filters.length === 1) {
        setBadgeVisibile(false);
        setClearVisible(false);
        setDisplayedFilters([...filters]);
        setHiddenFilters([]);
      } else {
        if (clearAllWidth + totalFiltersWidth > containerWidth) {
          const dFilters = [];
          const hFilters = [];

          let displayedWidth = badgeWidth;
          filtersWidths.forEach((width, index) => {
            if (displayedWidth + width < containerWidth) {
              displayedWidth += width;
              dFilters.push(filters[index]);
            } else {
              hFilters.push(filters[index]);
            }
          });

          if(hFilters.length === 0){
            hFilters.push(dFilters.pop());
          }

          setBadgeVisibile(true);
          setClearVisible(false);
          setDisplayedFilters(dFilters);
          setHiddenFilters(hFilters);
        } else {
          setBadgeVisibile(false);
          setClearVisible(true);
          setDisplayedFilters([...filters]);
          setHiddenFilters([]);
        }
      }

      selectedFilterEl.removeChild(container);
    };
    const handleWindowResize = () => {
      arrangeFilters();
    };

    arrangeFilters();

    window.addEventListener("resize", handleWindowResize);

    return () => {
      window.removeEventListener("resize", handleWindowResize);
    };
  }, [filters]);
  return (
    <div id="selected-filter" ref={selectedFilterRef}>
      <div id="dummy-container" style={{ visibility: "hidden" }}></div>
      <div className={styles.selectedFilters}>
        {displayedFilters.map((filter) => (
          <span className={styles.filter} key={filter}>
            {filter}
          </span>
        ))}
        {isClearVisible && <button type="button" className={styles.clearAll}>Clear all</button>}
        {isBadgeVisible && (
          <span className={styles.badge}>+{hiddenFilters.length}</span>
        )}
      </div>
      <div style={{ marginTop: 50 }}>
        Hidden filters
        {hiddenFilters.map((filter) => (
          <span className={styles.filter} key={filter}>
            {filter}
          </span>
        ))}
      </div>
    </div>
  );
}

export default SelectedFilters;
